IndiaPincodesApp-CSPFixed
=========================

India Pincodes App with Firefox OS Marketplace CSP Violation fixed.

In this project, we have simply moved our code from inside of <script> tag and into a separate app.js file. 

This is done to address the Firefox CSP Violation : https://developer.mozilla.org/en-US/docs/Security/CSP

This project is referenced as part of Episode 4  the Firefox OS Tutorial Series. 

The entire tutorial can be accessed at [rominirani.com/category/mobile-2/firefox-os/](http://rominirani.com/category/mobile-2/firefox-os/)

